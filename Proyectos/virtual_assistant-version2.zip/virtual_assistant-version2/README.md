# virtual_assistant
[![miniatura2][miniatura2]](https://youtu.be/Cr9O31eqXuA)
Turning on modules...

[miniatura2]: https://raw.githubusercontent.com/avmmodules/virtual_assistant/version2/src/img/miniatura_v2.png